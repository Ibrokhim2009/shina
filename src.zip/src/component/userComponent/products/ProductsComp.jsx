// import axios from 'axios'
// import React, { useContext, useState } from 'react'
// import { prodUrl } from '../../../../Urls'
// import { Context } from '../../../App'
// import { CiMenuKebab } from 'react-icons/ci'
// import { SlBasket } from 'react-icons/sl'
// import { FaHeart } from 'react-icons/fa'

// function ProductsComp({ item }) {
//     const { handleDelete, tokenState, basketCard, setBasketCard } = useContext(Context)
//     const [menuShow, setMenuShow] = useState(false)
//     const addToCart = () => {
//         setBasketCard([basketCard, item]);
//         console.log([basketCard, item])
//     };
//     return (
       
//     )
// }

// export default ProductsComp